import type { NextPage } from "next";
import { useMemo, type CSSProperties } from "react";
import styles from "./frame-component2.module.css";

export type FrameComponent2Type = {
  continueWithApple?: string;
  continueWithGoogle?: string;
  continueWithFacebook?: string;
  alreadyHaveAnAccount?: string;

  /** Style props */
  propPadding?: CSSProperties["padding"];
  propPadding1?: CSSProperties["padding"];
  propBorder?: CSSProperties["border"];
  propBorder1?: CSSProperties["border"];
  propGap?: CSSProperties["gap"];
  propWidth?: CSSProperties["width"];
  propTextAlign?: CSSProperties["textAlign"];

  /** Action props */
  onAlreadyHaveAnClick?: () => void;
};

const FrameComponent2: NextPage<FrameComponent2Type> = ({
  continueWithApple,
  continueWithGoogle,
  continueWithFacebook,
  alreadyHaveAnAccount,
  propPadding,
  propPadding1,
  propBorder,
  propBorder1,
  propGap,
  propWidth,
  propTextAlign,
  onAlreadyHaveAnClick,
}) => {
  const antDesignFacebookFrameStyle: CSSProperties = useMemo(() => {
    return {
      padding: propPadding,
    };
  }, [propPadding]);

  const antDesignFacebookFrame1Style: CSSProperties = useMemo(() => {
    return {
      padding: propPadding1,
    };
  }, [propPadding1]);

  const antDesignFacebookFrame2Style: CSSProperties = useMemo(() => {
    return {
      border: propBorder,
    };
  }, [propBorder]);

  const rectangleDivStyle: CSSProperties = useMemo(() => {
    return {
      border: propBorder1,
    };
  }, [propBorder1]);

  const frameDivStyle: CSSProperties = useMemo(() => {
    return {
      gap: propGap,
    };
  }, [propGap]);

  const alreadyHaveAnStyle: CSSProperties = useMemo(() => {
    return {
      width: propWidth,
      textAlign: propTextAlign,
    };
  }, [propWidth, propTextAlign]);

  return (
    <section className={styles.appleGoogleContinue}>
      <button
        className={styles.antDesignFacebookFrame}
        style={antDesignFacebookFrameStyle}
      >
        <div className={styles.antDesignFacebookFrameChild} />
        <img
          className={styles.antDesignappleFilledIcon}
          alt=""
          src="/antdesignapplefilled.svg"
        />
        <div className={styles.continueWithApple}>{continueWithApple}</div>
      </button>
      <button
        className={styles.antDesignFacebookFrame1}
        style={antDesignFacebookFrame1Style}
      >
        <div className={styles.antDesignFacebookFrameItem} />
        <img
          className={styles.flatColorIconsgoogle}
          alt=""
          src="/flatcoloriconsgoogle.svg"
        />
        <div className={styles.continueWithGoogle}>{continueWithGoogle}</div>
      </button>
      <button
        className={styles.antDesignFacebookFrame2}
        style={antDesignFacebookFrame2Style}
      >
        <div
          className={styles.antDesignFacebookFrameInner}
          style={rectangleDivStyle}
        />
        <div
          className={styles.brandicofacebookRectParent}
          style={frameDivStyle}
        >
          <img
            className={styles.brandicofacebookRectIcon}
            alt=""
            src="/brandicofacebookrect.svg"
          />
          <div className={styles.continueWithFacebook}>
            {continueWithFacebook}
          </div>
        </div>
      </button>
      <div
        className={styles.alreadyHaveAn}
        onClick={onAlreadyHaveAnClick}
        style={alreadyHaveAnStyle}
      >
        {alreadyHaveAnAccount}
      </div>
    </section>
  );
};

export default FrameComponent2;
