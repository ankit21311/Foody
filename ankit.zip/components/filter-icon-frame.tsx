import type { NextPage } from "next";
import styles from "./filter-icon-frame.module.css";

const FilterIconFrame: NextPage = () => {
  return (
    <section className={styles.filterIconFrame}>
      <div className={styles.scrollFrame}>
        <h2 className={styles.recommended}>Recommended</h2>
      </div>
      <div className={styles.recommendedScroll}>
        <div className={styles.unsplashImages}>
          <div className={styles.chholeFrame}>
            <img
              className={styles.unsplashvgtntt8pmimIcon}
              alt=""
              src="/unsplashvgtntt8pmim@2x.png"
            />
            <img
              className={styles.chholePhotoIcon}
              alt=""
              src="/chhole-photo@2x.png"
            />
            <img
              className={styles.oatPhotoIcon}
              loading="eager"
              alt=""
              src="/oat-photo@2x.png"
            />
            <img
              className={styles.avocadoPhotoIcon}
              loading="eager"
              alt=""
              src="/avocado-photo@2x.png"
            />
          </div>
          <div className={styles.salmonText}>
            <div className={styles.recommendedScroll1}>
              <div className={styles.chhole}>
                <div className={styles.svg}>
                  <p className={styles.kadhai}>Kadhai</p>
                  <p className={styles.paneer}>Paneer</p>
                  <p className={styles.mins}>15-30 mins</p>
                  <p className={styles.forOne}>₹90-150 for one</p>
                </div>
              </div>
              <div className={styles.chhole1}>
                <img
                  className={styles.chholeIcon}
                  alt=""
                  src="/pluscircle.svg"
                />
              </div>
              <div className={styles.chhole2}>
                <div className={styles.chatWithWebsiteContainer}>
                  <p className={styles.chhole3}>Chhole</p>
                  <p className={styles.kulche}>Kulche</p>
                  <p className={styles.mins1}>15-20 mins</p>
                  <p className={styles.forOne1}>₹80-120 for one</p>
                </div>
              </div>
              <div className={styles.chhole4}>
                <img
                  className={styles.chholeIcon1}
                  alt=""
                  src="/pluscircle.svg"
                />
              </div>
              <div className={styles.avocadoText}>
                <p className={styles.oatmeal}>Oatmeal</p>
                <p className={styles.mins2}>2-6 mins</p>
                <p className={styles.forOne2}>₹50-150 for one</p>
              </div>
              <div className={styles.chhole5}>
                <img
                  className={styles.chholeIcon2}
                  alt=""
                  src="/pluscircle.svg"
                />
              </div>
              <div className={styles.chhole6}>
                <div className={styles.salmonText1}>
                  <p className={styles.avocado}>Avocado</p>
                  <p className={styles.onToast}>on Toast</p>
                  <p className={styles.mins3}>3-8 mins</p>
                  <p className={styles.forOne3}>₹900-1500 for one</p>
                </div>
                <img
                  className={styles.chholeIcon3}
                  alt=""
                  src="/pluscircle.svg"
                />
              </div>
            </div>
          </div>
        </div>
        <div className={styles.bottomBar}>
          <div className={styles.salmonImage}>
            <img
              className={styles.salmonPhotoIcon}
              loading="eager"
              alt=""
              src="/salmon-photo@2x.png"
            />
            <img className={styles.chholeIcon4} alt="" src="/pluscircle.svg" />
          </div>
          <div className={styles.svg1}>
            <p className={styles.poached}>Poached</p>
            <p className={styles.salmon}>Salmon</p>
            <p className={styles.mins4}>25-40 mins</p>
            <p className={styles.forOne4}>₹400-700 for one</p>
          </div>
        </div>
        <div className={styles.bottomBar1}>
          <div className={styles.salmonText2}>
            <p className={styles.protein}>Protein</p>
            <p className={styles.cookies}>Cookies</p>
            <p className={styles.mins5}>15-30 mins</p>
            <p className={styles.forOne5}>₹120-200 for one</p>
          </div>
          <img className={styles.chholeIcon5} alt="" src="/pluscircle.svg" />
          <img
            className={styles.unsplashkid9sxbj3bqIcon}
            loading="eager"
            alt=""
            src="/unsplashkid9sxbj3bq@2x.png"
          />
        </div>
      </div>
    </section>
  );
};

export default FilterIconFrame;
