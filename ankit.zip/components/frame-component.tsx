import type { NextPage } from "next";
import styles from "./frame-component.module.css";

const FrameComponent: NextPage = () => {
  return (
    <div className={styles.frameParent}>
      <div className={styles.searchBarContainerWrapper}>
        <div className={styles.searchBarContainer}>
          <img
            className={styles.emojioneMonotoneforkAndKniIcon}
            loading="eager"
            alt=""
            src="/emojionemonotoneforkandknife@2x.png"
          />
          <div className={styles.verticalScroll}>
            <img
              className={styles.browseByCategorySection}
              loading="eager"
              alt=""
            />
          </div>
          <div className={styles.foody}>FOODY</div>
        </div>
      </div>
      <div className={styles.fOODYTEXT}>
        <div className={styles.searchBar}>
          <img
            className={styles.magnifyingglassIcon}
            alt=""
            src="/magnifyingglass-1.svg"
          />
          <input className={styles.search} placeholder="Search" type="text" />
        </div>
        <img
          className={styles.filterIcon}
          loading="eager"
          alt=""
          src="/filter-icon.svg"
        />
      </div>
    </div>
  );
};

export default FrameComponent;
