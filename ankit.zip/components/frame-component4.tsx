import type { NextPage } from "next";
import { useCallback } from "react";
import { useRouter } from "next/router";
import styles from "./frame-component4.module.css";

const FrameComponent4: NextPage = () => {
  const router = useRouter();

  const onXSignUpClick = useCallback(() => {
    router.push("/k-p-welcome");
  }, [router]);

  const onXSignUp1Click = useCallback(() => {
    router.push("/k-p-welcome");
  }, [router]);

  const onXSignUp2Click = useCallback(() => {
    router.push("/k-p-welcome");
  }, [router]);

  return (
    <section className={styles.frameParent}>
      <div className={styles.logInButtonParent}>
        <div className={styles.logInButton}>
          <h2 className={styles.logIn}>Log in</h2>
          <div className={styles.email}>Email</div>
        </div>
        <div className={styles.xsignUpButton}>
          <img
            className={styles.xSignUp}
            alt=""
            src="/x--sign-up.svg"
            onClick={onXSignUpClick}
          />
          <img
            className={styles.xSignUp1}
            alt=""
            src="/x--sign-up.svg"
            onClick={onXSignUp1Click}
          />
          <img
            className={styles.xSignUp2}
            loading="eager"
            alt=""
            src="/x--sign-up.svg"
            onClick={onXSignUp2Click}
          />
        </div>
      </div>
      <div className={styles.rectangleWrapper}>
        <input className={styles.frameChild} type="text" />
      </div>
      <div className={styles.passwordWrapper}>
        <div className={styles.password}>Password</div>
      </div>
      <div className={styles.rectangleContainer}>
        <input className={styles.frameItem} type="text" />
      </div>
      <div className={styles.forgotPassword}>Forgot Password?</div>
    </section>
  );
};

export default FrameComponent4;
