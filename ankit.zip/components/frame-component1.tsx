import type { NextPage } from "next";
import { useCallback } from "react";
import { useRouter } from "next/router";
import styles from "./frame-component1.module.css";

const FrameComponent1: NextPage = () => {
  const router = useRouter();

  const onRectangleClick = useCallback(() => {
    router.push("/k-p-sign-up");
  }, [router]);

  const onGroupClick = useCallback(() => {
    router.push("/k-p-log-in");
  }, [router]);

  return (
    <section className={styles.childRectangleWrapper}>
      <div className={styles.childRectangle}>
        <div className={styles.fRAME}>
          <div className={styles.rectangle}>
            <div className={styles.emojioneMonotoneforkAndKniParent}>
              <img
                className={styles.emojioneMonotoneforkAndKniIcon}
                loading="eager"
                alt=""
                src="/emojionemonotoneforkandknife1@2x.png"
              />
              <div className={styles.line}>
                <img
                  className={styles.parentFrameIcon}
                  loading="eager"
                  alt=""
                />
              </div>
              <div className={styles.fOODY}>
                <h1 className={styles.foody}>FOODY</h1>
              </div>
            </div>
          </div>
          <div
            className={styles.eatBetterWaste}
          >{`Eat Better, Waste Less & Save More`}</div>
        </div>
        <div className={styles.createFrame}>
          <button className={styles.rectangleParent}>
            <div className={styles.frameChild} onClick={onRectangleClick} />
            <div className={styles.createAnAccount}>Create an account</div>
          </button>
          <div className={styles.groupParent}>
            <div className={styles.group} onClick={onGroupClick} />
            <div className={styles.alreadyAMember}>Already a member?</div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default FrameComponent1;
