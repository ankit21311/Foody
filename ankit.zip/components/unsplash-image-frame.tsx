import type { NextPage } from "next";
import styles from "./unsplash-image-frame.module.css";

const UnsplashImageFrame: NextPage = () => {
  return (
    <section className={styles.unsplashImageFrame}>
      <div className={styles.mostPopularScroll}>
        <h2 className={styles.mostPopular}>Most Popular</h2>
      </div>
      <div className={styles.mostPopScroll}>
        <div className={styles.pancakeText}>
          <div className={styles.tacoText}>
            <img
              className={styles.saladPhotoIcon}
              loading="eager"
              alt=""
              src="/salad-photo@2x.png"
            />
            <img
              className={styles.pastaPhotoIcon}
              loading="eager"
              alt=""
              src="/pasta-photo@2x.png"
            />
            <img
              className={styles.pancakePhotoIcon}
              loading="eager"
              alt=""
              src="/pancake-photo@2x.png"
            />
            <img
              className={styles.tacoPhotoIcon}
              loading="eager"
              alt=""
              src="/taco-photo@2x.png"
            />
            <img
              className={styles.unsplashzcugjyqewe8Icon}
              loading="eager"
              alt=""
              src="/unsplashzcugjyqewe8@2x.png"
            />
          </div>
        </div>
        <div className={styles.chholeFrame}>
          <div className={styles.oatFrame}>
            <div className={styles.recommendedScroll}>
              <div className={styles.saladBox}>
                <p className={styles.greekSalad}>Greek Salad</p>
                <p className={styles.mins}>5-10 mins</p>
                <p className={styles.forOne}>₹70-120 for one</p>
              </div>
              <div className={styles.linkSvgContainer}>
                <p className={styles.greekSalad1}>Greek Salad</p>
                <p className={styles.mins1}>5-10 mins</p>
                <p className={styles.forOne1}>₹70-120 for one</p>
              </div>
            </div>
            <img
              className={styles.pluscircleIcon}
              loading="eager"
              alt=""
              src="/pluscircle.svg"
            />
            <div className={styles.avocadoText}>
              <div className={styles.headingContainer}>
                <p className={styles.arrabiata}>Arrabiata</p>
                <p className={styles.pasta}>Pasta</p>
                <p className={styles.mins2}>15-20 mins</p>
                <p className={styles.forOne2}>₹150-250 for one</p>
              </div>
              <img
                className={styles.pluscircleIcon1}
                loading="eager"
                alt=""
                src="/pluscircle.svg"
              />
            </div>
            <div className={styles.avocadoText1}>
              <div className={styles.after}>
                <p className={styles.banana}>Banana</p>
                <p className={styles.pancakes}>Pancakes</p>
                <p className={styles.mins3}>10-15 mins</p>
                <p className={styles.forOne3}>₹80-150 for one</p>
              </div>
              <img
                className={styles.pluscircleIcon2}
                loading="eager"
                alt=""
                src="/pluscircle.svg"
              />
            </div>
            <div className={styles.avocadoText2}>
              <div className={styles.tacoText1}>
                <p className={styles.chickpea}>Chickpea</p>
                <p className={styles.tacos}>Tacos</p>
                <p className={styles.mins4}>20-30 mins</p>
                <p className={styles.forOne4}>₹150-250 for one</p>
              </div>
              <img
                className={styles.pluscircleIcon3}
                loading="eager"
                alt=""
                src="/pluscircle.svg"
              />
            </div>
            <div className={styles.tacoText2}>
              <div className={styles.linkWikiContainer}>
                <p className={styles.frenchToast}>French Toast</p>
                <p className={styles.mins5}>5-12 mins</p>
                <p className={styles.forOne5}>₹150-250 for one</p>
              </div>
              <img
                className={styles.pluscircleIcon4}
                alt=""
                src="/pluscircle.svg"
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default UnsplashImageFrame;
