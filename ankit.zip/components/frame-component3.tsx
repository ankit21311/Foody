import type { NextPage } from "next";
import { useCallback } from "react";
import { useRouter } from "next/router";
import styles from "./frame-component3.module.css";

const FrameComponent3: NextPage = () => {
  const router = useRouter();

  const onXSignUpClick = useCallback(() => {
    router.push("/k-p-welcome");
  }, [router]);

  const onTermsAndConditionsClick = useCallback(() => {
    router.push("/");
  }, [router]);

  return (
    <section className={styles.frameParent}>
      <div className={styles.closeButtonXParent}>
        <div className={styles.closeButtonX}>
          <div className={styles.passwordInput}>
            <div className={styles.continueButton}>
              <h2 className={styles.signUp}>Sign up</h2>
              <div className={styles.email}>Email</div>
            </div>
            <img
              className={styles.xSignUp}
              loading="eager"
              alt=""
              src="/x--sign-up.svg"
              onClick={onXSignUpClick}
            />
          </div>
        </div>
        <div className={styles.signUpButton}>
          <input className={styles.emailInput} type="text" />
        </div>
        <div className={styles.googleSignUp}>
          <div className={styles.password}>Password</div>
        </div>
        <div className={styles.signUpButton1}>
          <input className={styles.signUpButtonChild} type="text" />
        </div>
        <button className={styles.continueWithText}>
          <div
            className={styles.termsAndConditions}
            onClick={onTermsAndConditionsClick}
          />
          <div className={styles.continue}>Continue</div>
        </button>
        <div className={styles.termsAndConditions1}>Terms and Conditions</div>
      </div>
      <div className={styles.frameLine}>
        <img
          className={styles.frameLineChild}
          loading="eager"
          alt=""
          src="/line-3.svg"
        />
        <div className={styles.or}>or</div>
        <img
          className={styles.frameLineItem}
          loading="eager"
          alt=""
          src="/line-4.svg"
        />
      </div>
    </section>
  );
};

export default FrameComponent3;
