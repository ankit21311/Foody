import type { NextPage } from "next";
import styles from "./q-u-i-c-k-a-n-d-e-a-s-y-s-e-c.module.css";

const QUICKANDEASYSEC: NextPage = () => {
  return (
    <section className={styles.qUICKANDEASYSEC}>
      <div className={styles.dESSERTPHOTOSFR}>
        <h2 className={styles.browseByCategory}>Browse by Category</h2>
      </div>
      <div className={styles.categoryScroll}>
        <div className={styles.mUSCLEGAIN}>
          <div className={styles.dESSERTPHOTOWEI}>
            <img
              className={styles.dessertPhotoIcon}
              loading="eager"
              alt=""
              src="/dessert-photo@2x.png"
            />
            <h3 className={styles.dessert}>DESSERT</h3>
          </div>
          <div className={styles.delightfulTreatsTo}>
            Delightful treats to satisfy your sweet tooth
          </div>
        </div>
        <div className={styles.verticalScroll}>
          <div className={styles.browseFrame}>
            <div className={styles.saladCategory}>
              <img
                className={styles.indulgentPhotoIcon}
                loading="eager"
                alt=""
                src="/indulgent-photo@2x.png"
              />
              <h3 className={styles.indulgent}>INDULGENT</h3>
            </div>
            <div className={styles.deliciousFoodsAre}>
              Delicious foods are sure to satisfy your craving
            </div>
          </div>
          <div className={styles.browseFrame1}>
            <div className={styles.quickPhotoParent}>
              <img
                className={styles.quickPhotoIcon}
                loading="eager"
                alt=""
                src="/quick-photo@2x.png"
              />
              <h3 className={styles.quickEasy}>{`QUICK & EASY`}</h3>
            </div>
            <div className={styles.simpleSnacksThat}>
              Simple snacks that take only minutes to prepare
            </div>
          </div>
        </div>
        <div className={styles.mUSCLEGAIN1}>
          <div className={styles.weightlossPhotoParent}>
            <img
              className={styles.weightlossPhotoIcon}
              loading="eager"
              alt=""
              src="/weightloss-photo@2x.png"
            />
            <h3 className={styles.weightLoss}>WEIGHT-LOSS</h3>
          </div>
          <div className={styles.mealsForThose}>
            Meals for those trying to lose weight
          </div>
        </div>
        <div className={styles.mUSCLEGAIN2}>
          <div className={styles.musclePhotoParent}>
            <img
              className={styles.musclePhotoIcon}
              loading="eager"
              alt=""
              src="/muscle-photo@2x.png"
            />
            <h3 className={styles.muscleGain}>
              <p className={styles.muscle}>MUSCLE</p>
              <p className={styles.gain}>GAIN</p>
            </h3>
          </div>
          <div className={styles.mealsForThose1}>
            Meals for those looking to put on muscle
          </div>
        </div>
        <div className={styles.mostPopFrame} />
      </div>
    </section>
  );
};

export default QUICKANDEASYSEC;
