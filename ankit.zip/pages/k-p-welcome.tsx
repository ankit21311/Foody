import type { NextPage } from "next";
import FrameComponent1 from "../components/frame-component1";
import styles from "./k-p-welcome.module.css";

const KPWelcome: NextPage = () => {
  return (
    <div className={styles.kpWelcome}>
      <div className={styles.wrapperImage5}>
        <img className={styles.image5Icon} alt="" src="/image-5@2x.png" />
      </div>
      <FrameComponent1 />
    </div>
  );
};

export default KPWelcome;
