import type { NextPage } from "next";
import { useCallback } from "react";
import { useRouter } from "next/router";
import FrameComponent3 from "../components/frame-component3";
import FrameComponent2 from "../components/frame-component2";
import styles from "./k-p-sign-up.module.css";

const KPSignUp: NextPage = () => {
  const router = useRouter();

  const onAlreadyHaveAnClick = useCallback(() => {
    router.push("/k-p-log-in");
  }, [router]);

  return (
    <div className={styles.kpSignUp}>
      <main className={styles.rectangleParent}>
        <div className={styles.frameChild} />
        <FrameComponent3 />
        <FrameComponent2
          continueWithApple="Continue with Apple"
          continueWithGoogle="Continue with Google"
          continueWithFacebook="Continue with Facebook"
          alreadyHaveAnAccount="Already have an account?"
          onAlreadyHaveAnClick={onAlreadyHaveAnClick}
        />
      </main>
    </div>
  );
};

export default KPSignUp;
