import type { NextPage } from "next";
import FrameComponent from "../components/frame-component";
import QUICKANDEASYSEC from "../components/q-u-i-c-k-a-n-d-e-a-s-y-s-e-c";
import UnsplashImageFrame from "../components/unsplash-image-frame";
import FilterIconFrame from "../components/filter-icon-frame";
import styles from "./index.module.css";

const KPHomePage: NextPage = () => {
  return (
    <div className={styles.kpHomePage}>
      <div className={styles.searchBar}>
        <div className={styles.search}>Search</div>
        <img
          className={styles.magnifyingglassIcon}
          alt=""
          src="/magnifyingglass.svg"
        />
      </div>
      <FrameComponent />
      <main className={styles.verticalScroll}>
        <QUICKANDEASYSEC />
        <UnsplashImageFrame />
        <FilterIconFrame />
      </main>
      <footer className={styles.bottomBar}>
        <img
          className={styles.houseIcon}
          loading="eager"
          alt=""
          src="/house.svg"
        />
        <img
          className={styles.shoppingcartsimpleIcon}
          alt=""
          src="/shoppingcartsimple.svg"
        />
        <img
          className={styles.userIcon}
          loading="eager"
          alt=""
          src="/user.svg"
        />
      </footer>
    </div>
  );
};

export default KPHomePage;
