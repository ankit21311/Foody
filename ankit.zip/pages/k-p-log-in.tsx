import type { NextPage } from "next";
import { useCallback } from "react";
import { useRouter } from "next/router";
import FrameComponent4 from "../components/frame-component4";
import FrameComponent2 from "../components/frame-component2";
import styles from "./k-p-log-in.module.css";

const KPLogIn: NextPage = () => {
  const router = useRouter();

  const onDontHaveAnClick = useCallback(() => {
    router.push("/k-p-sign-up");
  }, [router]);

  const onOrTextClick = useCallback(() => {
    router.push("/");
  }, [router]);

  return (
    <div className={styles.kpLogIn}>
      <main className={styles.rectangleParent}>
        <div className={styles.frameChild} />
        <FrameComponent4 />
        <section className={styles.divider}>
          <div className={styles.orText} onClick={onOrTextClick} />
          <div className={styles.logIn}>Log in</div>
        </section>
        <div className={styles.logInWithApple}>
          <img
            className={styles.logInWithAppleChild}
            loading="eager"
            alt=""
            src="/line-3.svg"
          />
          <div className={styles.or}>or</div>
          <img
            className={styles.logInWithAppleItem}
            loading="eager"
            alt=""
            src="/line-4.svg"
          />
        </div>
        <FrameComponent2
          continueWithApple="Log in with Apple"
          continueWithGoogle="Log in with Google"
          continueWithFacebook="Log in with Facebook"
          alreadyHaveAnAccount="Don’t have an account?"
          propPadding="var(--padding-3xs) var(--padding-xl)"
          propPadding1="var(--padding-3xs) 80px var(--padding-3xs) 78px"
          propBorder="none"
          propBorder1="unset"
          propGap="15px"
          propWidth="unset"
          propTextAlign="center"
          onAlreadyHaveAnClick={onDontHaveAnClick}
        />
      </main>
    </div>
  );
};

export default KPLogIn;
